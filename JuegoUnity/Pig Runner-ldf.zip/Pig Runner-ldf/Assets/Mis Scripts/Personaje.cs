using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class Personaje : MonoBehaviour
{
    [Header("Movimiento")]
    public float velocidad = 5f;

    [Header("Salto")]
    public float fuerzaSalto = 5f;
    private bool isGrounded;
    public Transform groundCheck;
    public float groundRadius = 0.1f;
    public LayerMask groundLayer;

    [Header("Límite de caída")]
    public float limiteY = -7f;

    private Rigidbody2D rb;
    private float movimientoHorizontal = 0f;


    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        LeerMovimiento();
        LeerSalto();
        GirarSegunDireccion();
    }

    void FixedUpdate()
    {
        // Detección del suelo
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer);

        // Movimiento
        rb.linearVelocity = new Vector2(movimientoHorizontal * velocidad, rb.linearVelocity.y);

        // Comprobar límite de caída
        if (isGrounded && transform.position.y < limiteY)
        {
            TerminarPartida();
        }
    }

    private void LeerMovimiento()
    {
        movimientoHorizontal = 0f;

        if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
            movimientoHorizontal = -1f;
        if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
            movimientoHorizontal = 1f;
    }

    private void LeerSalto()
    {
        if (Keyboard.current.spaceKey.wasPressedThisFrame && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, fuerzaSalto);
        }
    }

    private void GirarSegunDireccion()
    {
        if (movimientoHorizontal != 0)
        {
            transform.localScale = new Vector3(Mathf.Sign(movimientoHorizontal) * 1.5f, 1.5f, 1.5f);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        DeteccionColisiones(collision);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        DeteccionColisiones(collision.collider);
    }

    private void DeteccionColisiones(Collider2D collision)
    {
        if (collision.CompareTag("Moneda"))
        {
            Destroy(collision.gameObject);
            UI_Controlador.Instance.SumarMoneda();
        }
        else if (collision.CompareTag("Bomba"))
        {
            Destroy(collision.gameObject);
            TerminarPartida();
        }
        else if (collision.CompareTag("Meta"))
        {
            // Pausar juego
            Time.timeScale = 0f;
            
        }
    }

    private void TerminarPartida()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    
}
